from django.urls import path
from . import views

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('analysis/', views.analysis, name='analysis'),
    path('prediction/', views.prediction, name='prediction'),
]
