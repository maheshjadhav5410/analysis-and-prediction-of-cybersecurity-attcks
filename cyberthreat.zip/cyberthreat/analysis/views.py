import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
import pickle
from django.shortcuts import render
from django import forms
from django.conf import settings
from .models import CyberThreat
import os
import seaborn as sns
import io
import base64
from django.shortcuts import render
from .models import CyberThreat

def homepage(request):
    return render(request, 'analysis/homepage.html')

def generate_base64_image():
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    buf.close()
    return image_base64

def analysis(request):
    # Fetch data from the model
    data = CyberThreat.objects.all().values()
    df = pd.DataFrame(data)

    # Attack Types Distribution Pie Chart
    attack_counts = df['attack_type'].value_counts()
    plt.figure(figsize=(10, 6))
    attack_counts.plot.pie(autopct='%1.1f%%', startangle=90, colors=sns.color_palette("coolwarm", len(attack_counts)))
    plt.title('Attack Types Distribution')
    plt.ylabel('')
    image_base64 = generate_base64_image()
    plt.close()

    # Attack Frequency Over Time (Time Series)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    time_series = df.set_index('timestamp').resample('M').size()
    plt.figure(figsize=(10, 6))
    time_series.plot()
    plt.title('Attack Frequency Over Time')
    plt.xlabel('Time')
    plt.ylabel('Number of Attacks')
    time_series_base64 = generate_base64_image()
    plt.close()

    # Heatmap of Attacks by Source and Destination IP
    heatmap_data = pd.crosstab(df['source_ip'], df['destination_ip'])
    plt.figure(figsize=(10, 6))
    sns.heatmap(heatmap_data, cmap="YlGnBu", linewidths=.5)
    plt.title('Heatmap of Attacks by IP')
    heatmap_base64 = generate_base64_image()
    plt.close()

    # Common Attack Sources and Destinations
    source_counts = df['source_ip'].value_counts().head(5)
    destination_counts = df['destination_ip'].value_counts().head(5)
    common_ips = [(ip, count, 'Source') for ip, count in source_counts.items()] + [(ip, count, 'Destination') for ip, count in destination_counts.items()]

    # Pass the data and images to the template
    context = {
        'attack_counts': attack_counts,
        'image_base64': image_base64,
        'time_series_base64': time_series_base64,
        'heatmap_base64': heatmap_base64,
        'common_ips': common_ips,
    }
    return render(request, 'analysis/analysis.html', context)

class PredictionForm(forms.Form):
    packet_length = forms.FloatField(label='Packet Length')
    anomaly_scores = forms.FloatField(label='Anomaly Scores')
    source_ip = forms.IntegerField(label='Source IP (encoded)')
    destination_ip = forms.IntegerField(label='Destination IP (encoded)')

def prediction(request):
    if request.method == 'POST':
        form = PredictionForm(request.POST)
        if form.is_valid():
            packet_length = form.cleaned_data['packet_length']
            anomaly_scores = form.cleaned_data['anomaly_scores']
            source_ip = form.cleaned_data['source_ip']
            destination_ip = form.cleaned_data['destination_ip']
            
            # Correct paths to the model files
            model_severity_path = os.path.join(settings.BASE_DIR, 'model_severity.pkl')
            model_attack_path = os.path.join(settings.BASE_DIR, 'model_attack.pkl')
            
            # Load the pre-trained models
            with open(model_severity_path, 'rb') as file:
                model_severity = pickle.load(file)
                
            with open(model_attack_path, 'rb') as file:
                model_attack = pickle.load(file)
            
            # Make predictions
            features = [[packet_length, anomaly_scores, source_ip, destination_ip]]
            severity_level = model_severity.predict(features)[0]
            severity_proba = model_severity.predict_proba(features).max()
            attack_type = model_attack.predict(features)[0]
            attack_proba = model_attack.predict_proba(features).max()
            
            context = {
                'form': form,
                'severity_level': severity_level,
                'severity_proba': severity_proba,
                'attack_type': attack_type,
                'attack_proba': attack_proba,
            }
            return render(request, 'analysis/prediction.html', context)
    else:
        form = PredictionForm()
    return render(request, 'analysis/prediction.html', {'form': form})
